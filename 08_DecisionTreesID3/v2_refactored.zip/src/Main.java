import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args) throws IOException {
        //Dataset.fromFile("Data/breast-cancer.arff");
        Dataset dataset = Dataset.fromFile("Data/playgolf.data", "Yes", "No");
        List<Integer> attributes =
                IntStream.range(0, dataset.getAttributesCount()).boxed().collect(Collectors.toList());
        TreeNode tree = ID3DecisionTree.createTree(dataset, attributes);

        tree.printBFS();
    }
}
